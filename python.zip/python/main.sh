if [ -f ./web.zip ]; then 
	echo "正在下载web.zip"
	wget -O web.zip https://github.com/rendie-com/replit-rendie/releases/download/1.0/web.zip >/dev/null 2>&1 #下载zip
fi
if [ ! -d "/tmp/www" ]; then
	echo "正在解压web.zip"
	unzip -P $secrets_url -o web.zip -d /tmp/www >/dev/null 2>&1 #解压
	chmod a+x /tmp/www/web.dll #修改权限
fi
echo "下载更新完成。"
cd /tmp/www
dotnet web.dll --urls=http://0.0.0.0:80