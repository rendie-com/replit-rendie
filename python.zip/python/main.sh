wget -O ./python/web.zip https://github.com/rendie-com/replit-rendie/releases/download/1.0/web.zip >/dev/null 2>&1 #下载zip
echo "下载更新666完成。"