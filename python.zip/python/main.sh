#!/bin/bash
export PATH="~/nginx/sbin:~/${REPL_SLUG}/python:~/${REPL_SLUG}/tmp:$PATH"
echo "下载更新完成。"