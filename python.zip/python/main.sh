#!/bin/bash
echo "下载更新完成。"